package com.Banking_App.BankingApplication.BankController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Banking_App.BankingApplication.BankEntity.BankEntity;
import com.Banking_App.BankingApplication.Exception.ResourceNotFoundException;
import com.Banking_App.BankingApplication.Repository.BankRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/bankapp")
public class BankController {

	@Autowired
	private BankRepository bankrepository;
	
	@PostMapping("/create")
	public BankEntity createData(@RequestBody BankEntity data)
	{
		return bankrepository.save(data);
	}
	
	@GetMapping("/accountslist")
	public List<BankEntity> getAllacc()
	{
		return bankrepository.findAll();
		
	}
	
	@GetMapping("/account/{id}")
	public ResponseEntity<BankEntity> getAccDetails (@PathVariable(value="id")Long id)
	{
		BankEntity data = bankrepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Account Does not Exist's : "+id));
		return ResponseEntity.ok(data);
	}
	
	@DeleteMapping("/account/{id}") //Single  Account
	public ResponseEntity<Map<String,Boolean>> deleteAcc (@PathVariable(value="id")Long id)
	{
		BankEntity data = bankrepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Account is unavailable : "+id));
		
		bankrepository.delete(data);
		Map<String,Boolean> response = new HashMap<>();
		response.put("Account Deletec", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/allaccount")	//All Accounts
	public ResponseEntity<Map<String,Boolean>> deleteAllAcc()
	{		
		bankrepository.deleteAll();
		Map<String,Boolean> response = new HashMap<>();
		response.put("All account records are cleared ", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/account/{id}")
	public ResponseEntity<BankEntity> updateAccDetails (@PathVariable Long id, @RequestBody BankEntity bankdata)
	{
		BankEntity data = bankrepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Account details are updated : "+id));
		
		data.setAccountHolder(bankdata.getAccountHolder());
		data.setAccountNumber(bankdata.getAccountNumber());
		data.setBranch(bankdata.getBranch());
		data.setIFSCcode(bankdata.getIFSCcode());
		
		BankEntity updateAccDeatils = bankrepository.save(data);
		return ResponseEntity.ok(updateAccDeatils);
	}
}
