package com.Banking_App.BankingApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Banking_App.BankingApplication.BankEntity.BankEntity;

public interface BankRepository extends JpaRepository<BankEntity, Long> {

}
